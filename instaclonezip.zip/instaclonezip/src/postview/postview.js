import React from "react";
import Api from "../API/fetchapi";
const Postview = () => {
    return (
        <div>
            <Api />
        </div>
    )
}
export default Postview;